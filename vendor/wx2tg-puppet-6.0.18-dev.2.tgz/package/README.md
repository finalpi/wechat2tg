# wx2tg-puppet

微信机器人核心库，供 `wechat2tg` 调用 `wx2tg-server`。

## v6 当前稳定配套版本

| 仓库 | 维护分支 | 当前稳定 Git 标签 | npm / Docker 版本 |
| --- | --- | --- | --- |
| wechat2tg | `v6` | `v6.0.39` | 包版本 `6.0.39`；镜像 `finalpi/wechat2tg:v6.0.39` |
| wx2tg-puppet | `v6` | `v6.0.17` | npm 格式包 `wx2tg-puppet@6.0.17` |
| wx2tg-server（fk-zhang） | `v6`，继承 `875` | `v6.0.16` | 镜像 `finalpi/wx2tg-server:v6.0.16` |

**只维护 `v6` 分支，开发版和稳定版用 tag 区分，不建立 `v6-dev` 分支。** `v6.X.Y-dev.N` 为开发版，`v6.X.Y` 为稳定版；npm 不带前面的 `v`。三个组件在 v6 大版本内独立发布，不要求补丁版本号相同；本次 server 保持 v6.0.16。Docker 的 `v6-dev` 指向开发版、`v6` 指向稳定版，开发构建不得覆盖稳定别名。历史 `3.x`、`875`、`v51.*`、裸 `v6` 标签保留，不移动。

根目录 `VERSION`、`package.json`、`package-lock.json` 必须一致；发布标签必须为 `v${VERSION}`。创建本地标签不代表已推送或已发布 npm。发布前执行：

```sh
npm ci
npm run check:version
npm test
npm pack
```

`test.yml` 负责测试和 Actions 制品；`publish.yml` 在完整 `v6.*` 标签触发后重新验证、测试、打包并执行 `npm publish`。正式版使用 npm `latest`，开发版使用 `v6-dev`，不覆盖稳定标签。发布使用仓库 `NPM_TOKEN`，凭据缺失或失效会明确失败；还会检查 registry 确实能读取该版本。当前源码仓库为私有，不声称提供 npm provenance。分支推送和 PR 不发布 npm；可手动重试已有不可变标签。

`wechat2tg` 可继续锁定同版本本地制品以保证构建可重现；若切换 registry 来源，必须重新生成 lockfile 并校验制品，不要手工伪造 integrity。

## v6.0.18-dev.1：登录不再等待全量联系人（开发预览）

- 修复 `loginSuccess()` 等待所有联系人详情后才启动消息接收、发出登录事件的时序问题。恢复登录和扫码登录先启动接收与心跳，目录任务在后台处理；启动 Sync 取得的消息继续分发，不丢弃。
- `start()` / `loginTwice()` 完成不再代表全量目录同步结束。依赖初次完整目录的调用方可显式 `await bot.waitForContactSync()`；这是等待当前轮次，不保证失败项已成功，也不启动额外同步。
- `contacts-updated` 事件通知当前目录轮次结束（也包括后续分页失败后的部分更新），供调用方重新读取目录；不重新触发登录事件。
- 保留每页最多 4 个详情请求、逐项失败隔离及分页等待。跨登录任务串行衔接，旧任务不再启动剩余详情 / 下一页或发出完成通知。
- 联系人接口失败不主动退出账号；会话恢复仍由消息 Sync 的原有单次恢复逻辑负责。清缓存和切换扫码账号前等待旧在途写入结束，避免清空后被旧任务重新写入。
- 208 项离线测试通过，包括安全菜单元数据、联系人保持挂起时接收已就绪、积压消息不丢、退出 / 重新登录、失败处理和缓存清理顺序。未访问真实账号，不代表线上延迟已验收。
- 此开发包供 Bot `v6.0.40-dev.4` 使用；dev tag 只发布 npm `v6-dev` 通道，以发布工作流成功为准。不替换已发布的 `6.0.17` 制品，也不代表线上完整验收。

## v6.0.17：联系人初始化修复

- 修复初始化时异步详情查询未等待、未捕获，导致 `Contact detail response did not contain the requested contact` 等异常刷屏。
- 每页最多 4 个并发详情请求，等待本页完成后再翻页；单项失败不会中断其他联系人或群聊。
- 逐批记录成功 / 失败数量，不记录联系人 ID、接口原始数据或凭据。缺失详情仍明确计入失败，不伪造成功或删除缓存。
- 183 项测试通过；对应 Bot 修复已通过用户的临时部署验收。

## 消息接收

### polling（保持默认）

```ts
new WxBot({baseUrl: 'http://wx2tg-server:8058/api', databasePath: 'storage/db/puppet.db',
  deviceType: 'ipad', mode: 'polling'})
```

server 对应 `syncmessage=false`、`msgpush=false`。每秒拉取 `/Msg/Sync`，同一实例不会并发 Sync；同步进行中又收到通知时，会追加一次拉取。

### callback

设 `mode: 'callback'`、`callbackPort: 8056`；server 的 `syncmessagebusinessuri` 指向 `http://bot:8056/message/callback/{0}`，启用 `msgpush=true`，按需启用 `syncmessage=true` 作为短链兜底。

- 带正文回调直接处理 `Data.AddMsgs`，不再丢弃正文后二次拉取。当前 server 同时提供 `Data.Messages` 和兼容的 `Data.AddMsgs`。
- 兼容空通知和 Go 时间戳通知；它们才触发 Sync。每 5 分钟保留一次兜底 Sync。
- 64 位消息 ID 无损解析；回调和轮询通过同一队列、同一去重逻辑处理。进程内去重窗口 2 分钟，最多 10,000 项。
- 回调服务启动成功后发出 `login`；启动/恢复检查取得的消息也会处理，不再直接丢弃。
- 单个回调正文最大 8 MiB；非法信封 400，错误账号路径 404，超限 413，处理失败 500。单条消息失败最多在本地尝试 3 次，不阻断同批其他消息；部分失败也返回 500，不会回显消息正文。
- 只允许可信网络访问回调端口。当前 server 没有签名/token，本库不提供公网鉴权。

HTTP 200 仅表示 puppet 处理并同步发出了事件，不代表异步业务监听器或 Telegram 已成功处理。进程重启会清空去重与队列；server 的异步消息归档也不是可靠回调重试队列。需要端到端补发时，仍需单独设计持久化投递/游标补偿。

## 公众号识别

`Contact.verifyFlag` 保存 `/api/Friend/GetContractDetail` 返回的 `VerifyFlag`，`Contact.isOfficialAccount()` 返回 `true` / `false` / `undefined`。只有品牌位 `(VerifyFlag & 8) !== 0` 才判断为公众号，不根据 `gh_` 前缀，也不把任意非零值当作公众号。例如 `0`、`1`、`2`、`4`、`16` 均不是公众号，`8`、`24`、`136` 是公众号。

根入口导出 `normalizeContactVerifyFlag` 与 `isOfficialAccountVerifyFlag`。字段缺失或非法时保持未知，不能转换成 `0`。旧缓存通过 `Contact.find()` 按需补查，同一账号/联系人共享请求，未知结果有 30 秒冷却。显式 `0` 会更新旧分类，缺失字段不会抹掉已知标志。联系人详情请求有 15 秒超时，不再无限递归；缓存写入使用原子 upsert 避免并发重复主键。

此 SDK 管理 `puppet.db` 的联系人 schema。其他读取连接不要再次用不完整的镜像实体执行 schema synchronize，否则会删除新增字段。服务端目录接口的 `profile.verify_flag` 可用于批量补齐，但必须验证账号范围，不覆盖更新的已知值。

## 公众号类型与只读菜单元数据（6.0.18-dev.1 开发预览）

- `Contact.serviceType: number | null` 保留 `ContactList[0].CustomizedInfo.ExternalInfo` JSON 字符串中**顶层** `ServiceType` 的 uint32 原值（也接受规范十进制字符串）。仅详情本次明确带品牌位 8 的 `VerifyFlag` 时解析；不根据名称、ID、`BrandFlag` 或任意嵌套 `Type` 猜测。缺失/非法表示未知或保留旧值，绝不推断为订阅号/type 0。
- `Contact.officialMenu: OfficialMenu | null` 返回经过重新校验的菜单。根入口导出 `OfficialMenu`、`OfficialMenuButton` 类型及纯函数 `parseStoredOfficialMenu(value: unknown): OfficialMenu | null`，供其他只读 DB 连接解析 TEXT 缓存；每次返回新的安全对象。无法解析是 `null`；明确空菜单为 `{buttons: []}`，两者不可混同。
- `OfficialMenu` 为 `{buttons: OfficialMenuButton[]}`，按钮仅含 `name`、`kind: group | url | unsupported`，以及相应的 `children`、`url` 或 `reason: event | miniapp | wechat | unknown`。菜单组来自 type 0；普通网址只读取 type 2 的 **value**，不把 opaque key 当网址。type 1 事件和 type 5 小程序显示为不可执行项，不提供点击、授权或小程序执行 API。
- 仅允许无凭据/控制字符的 HTTP(S) 地址；微信协议、脚本、data 及 OAuth/授权地址均变成 `unsupported/wechat`，缓存中的 URL 同样重新验证。不保存原始 key、uin、appid、native_url、版本或其他任意字段。
- JSON/规范化结果最多 64 KiB、菜单最多 3 层/100 个节点、名称最多 256 字符、URL 最多 4096 字符。原始按钮 ID 可能全部相同，因此不作为身份或执行依据且不保存；超限、相同同级按钮、歧义子树、非法结构均拒绝整个菜单，不截断后冒充完整数据。缺失或非法菜单不覆盖已知缓存；显式空 `button_list` 才清除旧菜单。

Schema 仍由 SDK 管理：`contact.serviceType INTEGER NULL` 与 `contact.officialMenu TEXT NULL` 都无默认值。迁移顺序为已有 `contact-verify-flag.sql` schema → `OfficialAccountMetadata1760000000000`（`src/database/migrations/1760000000000-OfficialAccountMetadata.ts`）→ 原有 TypeORM synchronize。新迁移检查现有列并直接执行 additive `ALTER TABLE ADD COLUMN`，避免 SQLite 的 addColumn helper 重建旧联系人表；fresh DB 无 contact 表时跳过 ALTER，由后续 synchronize 创建完整 schema。已执行迁移记入 TypeORM migrations 表，重启不重复；不提供会丢失元数据的自动 down。`migrations/contact-official-metadata.sql` 仅为对应增量的版本控制参考，不需手工修改远程 DB。Bot 镜像连接必须保持 `synchronize=false`。

离线测试 `test/official-account-metadata.test.cjs` 使用合成数据覆盖真实详情入库路径、未知字段保留、菜单/URL 安全、隐私字段剔除、边界，以及旧/新 SQLite 初始化和旧行无重建保留。

## 接龙消息

`Message.Type.Solitaire` 对应外层 `49`、应用子类型 `53`。`Message.text()` 返回接龙完整可见标题、名单和尾注；原始 `Content`、`_text`、`_xml` 保持不变，不把内部 `solitaire_info` 当正文输出。CDATA、实体转义、前导零、Unicode 和换行保留；无法安全解析时返回明确的接龙占位提示。此功能只负责识别/读取，不自动参与、发送或重放历史接龙。

## 对齐 860-v3

当前 v6 源码合入 `860-v3` 的 `7d9590c`。登录恢复和同步互斥已经由 v6 独立覆盖，本轮保留其更完整的回调队列；补齐下载校验、选择性重试及兼容入口。详见 [上游对齐记录](docs/upstream-860-v3.md)。此源码整合不覆盖已发布 `v6.0.15` 制品，后续发布使用新协调版本。

## 文件下载

`6.0.13-dev.1` 新增 `toolsApi.DownloadFileBuffer(body): Promise<Buffer>`，从偏移 0 以最多 512 KiB 分片组装完整文件，保留参数和 64 位 ID，供合并的 WebUI / 消息中心使用。原有 v6 `DownloadFile()` 仍返回单片 `AxiosResponse<Buffer>`，没有替换为 npm 3.0.9 的不同契约，也没有回退带正文回调修复。

`v6.0.12` 支持 `/Tools/DownloadFile` 的 HTTP 200/206 二进制分片，按实际收到的字节数推进偏移，验证长度/范围，保留 64 位 `NewMsgId`。同时兼容旧 JSON/Base64 成功响应。

每次分片请求超时为 180 秒，以覆盖 server 首次 CDN 回退约 120 秒的预算。明确的暂时性网络错误及 HTTP 429/502/503/504 最多尝试 3 次，按 1/2 秒退避，仍从同一偏移继续；损坏内容、错误范围和确定的业务失败不重试。`FileDownloadError` 提供 `httpStatus`、`businessCode`、`retryable`，但不携带附件密钥、任意 server 正文或 Axios 请求对象。

新增 `DownloadFileBinary` 二进制别名、显式的 `DownloadFileLegacy` JSON/Base64 入口；`dist/utils/fileDownload` 的工具导出与上游兼容，复用同一个校验引擎。保持 v6 `DownloadFile` 返回 `AxiosResponse<Buffer>` 的原契约。

旧 JSON 必须有 `Success=true` 和 `Code=0`；已提供的 native ret、长度、偏移和总长度均需匹配。二进制 `206` 必须提供准确的 `Content-Range`，二进制 `200` 只能是从零开始的完整文件；旧 JSON 分片仍可返回 HTTP 200。响应元数据中的大整数也无损保留。

图片、视频及大于 80 MiB 文件的 `DownloadFileMessage` 路径仍保持原行为。

## 测试与构建

`npm test` 先编译，再同时运行 `test/` 与上游 `tests/` 下的 `node:test` 离线回归：回调正文、空通知、大整数、并发去重、登录事件、续登并发保护、二进制/旧 JSON 下载、分片推进、错误响应和不受影响的图片/视频路径。测试只访问本机随机端口，不登录微信或发送真实消息。

保留已发布 `3.0.8` 的单次续登保护及 v6 更完整的串行同步行为，避免上游早退逻辑丢弃待处理通知。仓库既有 `dist` 为被追踪产物，修改源码后需重新构建并一起提交。
