# wx2tg-puppet

微信机器人核心库，供 `wechat2tg` 调用 `wx2tg-server`。

## v6 配套版本

| 仓库 | 维护分支 | 本次 Git 标签 | npm / Docker 版本 |
| --- | --- | --- | --- |
| wechat2tg | `v6` | `v6.0.12` | npm 包版本 `6.0.12`；镜像 `finalpi/wechat2tg-v3:v6.0.12` |
| wx2tg-puppet | `v6` | `v6.0.12` | npm `wx2tg-puppet@6.0.12` |
| wx2tg-server（fk-zhang） | `v6`，继承 `875` | `v6.0.12` | 镜像 `finalpi/wx2tg-server:v6.0.12` |

`v6` 是项目兼容系列，不是微信内部协议版本。今后三仓库使用同一个完整发行版本号；npm 不带 `v`，Git/Docker 带 `v`。历史 `3.x`、`875`、`v51.*`、裸 `v6` 标签保留，不覆盖、不删除。`v7` 独立维护，本轮不发布 v7。

根目录 `VERSION`、`package.json`、`package-lock.json` 必须一致；发布标签必须为 `v${VERSION}`。创建本地标签不代表已推送或已发布 npm。发布前执行：

```sh
npm ci
npm run check:version
npm test
npm pack
```

npm 发布需要另行明确执行 `npm publish`，不是本次代码修改自动执行的步骤。`wechat2tg` 在 npm 新版本发布前可锁定本库打包的同版本本地制品；正式发布后再切换 registry 来源并更新 lockfile，不要手工伪造 registry 的 integrity。

## 消息接收

### polling（保持默认）

```ts
new WxBot({baseUrl: 'http://wx2tg-server:8058/api', databasePath: 'storage/db/puppet.db',
  deviceType: 'ipad', mode: 'polling'})
```

server 对应 `syncmessage=false`、`msgpush=false`。每秒拉取 `/Msg/Sync`，同一实例不会并发 Sync；同步进行中又收到通知时，会追加一次拉取。

### callback

设 `mode: 'callback'`、`callbackPort: 8056`；server 的 `syncmessagebusinessuri` 指向 `http://bot:8056/message/callback/{0}`，启用 `msgpush=true`，按需启用 `syncmessage=true` 作为短链兜底。

- 带正文回调直接处理 `Data.AddMsgs`，不再丢弃正文后二次拉取。当前 server 同时提供 `Data.Messages` 和兼容的 `Data.AddMsgs`。
- 兼容空通知和 Go 时间戳通知；它们才触发 Sync。每 5 分钟保留一次兜底 Sync。
- 64 位消息 ID 无损解析；回调和轮询通过同一队列、同一去重逻辑处理。进程内去重窗口 2 分钟，最多 10,000 项。
- 回调服务启动成功后发出 `login`；启动/恢复检查取得的消息也会处理，不再直接丢弃。
- 单个回调正文最大 8 MiB；非法信封 400，错误账号路径 404，超限 413，处理失败 500。单条消息失败最多在本地尝试 3 次，不阻断同批其他消息；部分失败也返回 500，不会回显消息正文。
- 只允许可信网络访问回调端口。当前 server 没有签名/token，本库不提供公网鉴权。

HTTP 200 仅表示 puppet 处理并同步发出了事件，不代表异步业务监听器或 Telegram 已成功处理。进程重启会清空去重与队列；server 的异步消息归档也不是可靠回调重试队列。需要端到端补发时，仍需单独设计持久化投递/游标补偿。

## 文件下载

`v6.0.12` 支持 `/Tools/DownloadFile` 的 HTTP 200/206 二进制分片，按实际收到的字节数推进偏移，验证长度/范围，保留 64 位 `NewMsgId`。同时兼容旧 JSON/Base64 成功响应。

每次分片请求超时为 180 秒，以覆盖 server 首次 CDN 回退约 120 秒的预算；普通文件沿用最多 3 次下载尝试。错误信息不泄露附件密钥、原始请求或任意 server 诊断正文。

图片、视频及大于 80 MiB 文件的 `DownloadFileMessage` 路径仍保持原行为。

## 测试与构建

`npm test` 先编译，再运行 `node:test` 离线回归：回调正文、空通知、大整数、并发去重、登录事件、续登并发保护、二进制/旧 JSON 下载、分片推进、错误响应和不受影响的图片/视频路径。测试只访问本机随机端口，不登录微信或发送真实消息。

本轮保留了已发布 `3.0.8` 的单次续登保护与串行同步行为，避免本地原 `3.0.7` 源码覆盖已有修复。仓库既有 `dist` 为被追踪产物，修改源码后需重新构建并一起提交。
